package react.model;

public class Credentials {
  private String username;
  private String password;

  public Credentials() {
  }

  public String getUsername() {
    return username;
  }

  public String getPassword() {
    return password;
  }
}
