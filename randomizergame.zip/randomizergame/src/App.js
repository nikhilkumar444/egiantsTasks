import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Quiz from './Quiz';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h2>Welcome to Nikhils RandomizerGame App using React</h2>
          <p>Done with task 36</p>
          <a href="http://www.theegiants.com/ " target="_blank"><img alt="egiants" height="40" width="139" src="egiant.jpg"/></a>
        </div>
        <Quiz />
      </div>
    );
  }
}

export default App;
